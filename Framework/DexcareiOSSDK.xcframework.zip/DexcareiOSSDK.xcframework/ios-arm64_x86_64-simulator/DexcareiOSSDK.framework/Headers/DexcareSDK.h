// Copyright © 2019 Providence. All rights reserved.

#import <UIKit/UIKit.h>

//! Project version number for DexcareSDK.
FOUNDATION_EXPORT double DexcareSDKVersionNumber;

//! Project version string for DexcareSDK.
FOUNDATION_EXPORT const unsigned char DexcareSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DexcareSDK/PublicHeader.h>


